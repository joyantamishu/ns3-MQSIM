#ifndef  NVM_TYPES_H
#define NVM_TYPES_H

#include <cstdint>
namespace ns3{
namespace NVM
{
	enum class NVM_Type {FLASH};
	typedef uint64_t memory_content_type;
}
}

#endif // !NVM_TYPES_H
