#ifndef NVM_MEMORY_ADDRESS_H
#define NVM_MEMORY_ADDRESS_H
namespace ns3{
namespace NVM
{
	class NVM_Memory_Address
	{

	};
}
}

#endif // !NVM_MEMORY_ADDRESS_H
