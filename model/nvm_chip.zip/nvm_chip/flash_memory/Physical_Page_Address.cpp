#include "Physical_Page_Address.h"
using namespace ns3;
namespace ns3{
namespace NVM
{
	namespace FlashMemory
	{
		bool Physical_Page_Address::block_address_constraint_for_multiplane = true;
	}
}
}
